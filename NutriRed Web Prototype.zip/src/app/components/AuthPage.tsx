import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Leaf, ArrowLeft, Building2, Heart, User } from "lucide-react";
import { Alert, AlertDescription } from "./ui/alert";

export default function AuthPage({ 
  onNavigate 
}: { 
  onNavigate: (page: string, userType?: string) => void 
}) {
  const [selectedRole, setSelectedRole] = useState("donante");
  const [loginError, setLoginError] = useState("");
  const [registerSuccess, setRegisterSuccess] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const email = (form.elements.namedItem('email') as HTMLInputElement).value;
    const password = (form.elements.namedItem('password') as HTMLInputElement).value;

    // Simulación de login
    if (email && password) {
      // Determinar tipo de usuario basado en email para demo
      if (email.includes('admin')) {
        onNavigate('admin-dashboard');
      } else if (email.includes('ong') || email.includes('beneficiario')) {
        onNavigate('ngo-dashboard');
      } else {
        onNavigate('donor-dashboard');
      }
    } else {
      setLoginError("Por favor completa todos los campos");
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterSuccess(true);
    setTimeout(() => {
      if (selectedRole === 'administrador') {
        onNavigate('admin-dashboard');
      } else if (selectedRole === 'ong' || selectedRole === 'beneficiario') {
        onNavigate('ngo-dashboard');
      } else {
        onNavigate('donor-dashboard');
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-white">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-[#4CAF50]" />
            <span className="text-[#4CAF50]">NutriRed</span>
          </div>
          <Button variant="ghost" onClick={() => onNavigate('landing')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver al inicio
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Iniciar sesión</TabsTrigger>
              <TabsTrigger value="register">Registrarse</TabsTrigger>
            </TabsList>

            {/* Login Tab */}
            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Bienvenido de nuevo</CardTitle>
                  <CardDescription>
                    Ingresa tus credenciales para acceder a tu cuenta
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleLogin} className="space-y-4">
                    {loginError && (
                      <Alert variant="destructive">
                        <AlertDescription>{loginError}</AlertDescription>
                      </Alert>
                    )}
                    <div className="space-y-2">
                      <Label htmlFor="email">Correo electrónico</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="tu@email.com"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Contraseña</Label>
                      <Input
                        id="password"
                        name="password"
                        type="password"
                        placeholder="••••••••"
                        required
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <a href="#" className="text-[#4CAF50] hover:underline">
                        ¿Olvidaste tu contraseña?
                      </a>
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full bg-[#4CAF50] hover:bg-[#45a049] text-white"
                    >
                      Iniciar sesión
                    </Button>
                    <div className="text-center text-gray-500">
                      <p>Demo: usa admin@nutrired.com para panel admin</p>
                      <p>ong@nutrired.com para panel ONG</p>
                      <p>donante@nutrired.com para panel donante</p>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Register Tab */}
            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Crear cuenta</CardTitle>
                  <CardDescription>
                    Únete a NutriRed y comienza a hacer la diferencia
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {registerSuccess && (
                    <Alert className="mb-4 border-[#4CAF50] bg-green-50">
                      <AlertDescription className="text-[#4CAF50]">
                        ¡Registro exitoso! Redirigiendo a tu dashboard...
                      </AlertDescription>
                    </Alert>
                  )}
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Tipo de cuenta</Label>
                      <RadioGroup value={selectedRole} onValueChange={setSelectedRole}>
                        <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                          <RadioGroupItem value="donante" id="donante" />
                          <Label htmlFor="donante" className="flex items-center gap-2 cursor-pointer flex-1">
                            <Building2 className="w-4 h-4 text-[#4CAF50]" />
                            <div>
                              <div>Donante</div>
                              <div className="text-gray-500">Supermercado, restaurante, agricultor</div>
                            </div>
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                          <RadioGroupItem value="ong" id="ong" />
                          <Label htmlFor="ong" className="flex items-center gap-2 cursor-pointer flex-1">
                            <Heart className="w-4 h-4 text-[#4CAF50]" />
                            <div>
                              <div>ONG / Organización</div>
                              <div className="text-gray-500">Fundación, asociación, comedor</div>
                            </div>
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                          <RadioGroupItem value="beneficiario" id="beneficiario" />
                          <Label htmlFor="beneficiario" className="flex items-center gap-2 cursor-pointer flex-1">
                            <User className="w-4 h-4 text-[#4CAF50]" />
                            <div>
                              <div>Beneficiario</div>
                              <div className="text-gray-500">Comunidad, centro de ayuda</div>
                            </div>
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="org-name">Nombre de la organización / persona</Label>
                      <Input
                        id="org-name"
                        placeholder="Ej: Supermercado El Ahorro"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reg-email">Correo electrónico</Label>
                      <Input
                        id="reg-email"
                        type="email"
                        placeholder="contacto@organizacion.com"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+34 600 000 000"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="location">Ubicación</Label>
                      <Input
                        id="location"
                        placeholder="Ciudad, País"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reg-password">Contraseña</Label>
                      <Input
                        id="reg-password"
                        type="password"
                        placeholder="••••••••"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirmar contraseña</Label>
                      <Input
                        id="confirm-password"
                        type="password"
                        placeholder="••••••••"
                        required
                      />
                    </div>

                    <div className="flex items-start space-x-2">
                      <input type="checkbox" id="terms" required className="mt-1" />
                      <Label htmlFor="terms" className="text-gray-600">
                        Acepto los términos y condiciones y la política de privacidad de NutriRed
                      </Label>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-[#4CAF50] hover:bg-[#45a049] text-white"
                    >
                      Crear cuenta
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
