import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  Package,
  Calendar,
  MapPin,
  User,
  ArrowRight
} from "lucide-react";
import DashboardLayout from "./DashboardLayout";

export default function NGORequests({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [requests] = useState([
    {
      id: 1,
      foodName: "Verduras frescas variadas",
      donor: "Supermercado El Ahorro",
      quantity: "50 kg",
      requestDate: "2025-10-18",
      status: "Pendiente",
      location: "Madrid Centro",
      pickupDate: "2025-10-22",
      contact: "+34 600 123 456"
    },
    {
      id: 2,
      foodName: "Pan del día",
      donor: "Panadería La Espiga",
      quantity: "30 unidades",
      requestDate: "2025-10-17",
      status: "Aceptada",
      location: "Madrid Norte",
      pickupDate: "2025-10-21",
      contact: "+34 600 789 012"
    },
    {
      id: 3,
      foodName: "Frutas variadas",
      donor: "Frutería Los Naranjos",
      quantity: "40 kg",
      requestDate: "2025-10-15",
      status: "Entregada",
      location: "Madrid Sur",
      pickupDate: "2025-10-18",
      contact: "+34 600 345 678"
    },
    {
      id: 4,
      foodName: "Conservas variadas",
      donor: "Almacén Central",
      quantity: "100 unidades",
      requestDate: "2025-10-16",
      status: "Pendiente",
      location: "Madrid Centro",
      pickupDate: "2025-10-23",
      contact: "+34 600 901 234"
    },
    {
      id: 5,
      foodName: "Productos lácteos",
      donor: "Supermercado Fresh",
      quantity: "25 litros",
      requestDate: "2025-10-14",
      status: "Rechazada",
      location: "Madrid Este",
      pickupDate: "-",
      contact: "-"
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pendiente": return "bg-yellow-100 text-yellow-800";
      case "Aceptada": return "bg-blue-100 text-blue-800";
      case "Entregada": return "bg-green-100 text-green-800";
      case "Rechazada": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Pendiente": return <Clock className="w-4 h-4" />;
      case "Aceptada": return <CheckCircle className="w-4 h-4" />;
      case "Entregada": return <CheckCircle className="w-4 h-4" />;
      case "Rechazada": return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const pendingRequests = requests.filter(r => r.status === "Pendiente");
  const acceptedRequests = requests.filter(r => r.status === "Aceptada");
  const completedRequests = requests.filter(r => r.status === "Entregada");
  const rejectedRequests = requests.filter(r => r.status === "Rechazada");

  const RequestCard = ({ request }: { request: typeof requests[0] }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h4 className="text-gray-900">{request.foodName}</h4>
              <Badge className={getStatusColor(request.status)}>
                <div className="flex items-center gap-1">
                  {getStatusIcon(request.status)}
                  {request.status}
                </div>
              </Badge>
            </div>
            <p className="text-gray-600">{request.donor}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4 text-gray-600">
          <div className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            <span>{request.quantity}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>{request.requestDate}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span>{request.location}</span>
          </div>
          {request.status === "Aceptada" && (
            <div className="flex items-center gap-2 text-[#4CAF50]">
              <Calendar className="w-4 h-4" />
              <span>Recogida: {request.pickupDate}</span>
            </div>
          )}
        </div>

        {request.status === "Aceptada" && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-3">
            <div className="flex items-center gap-2 text-green-800 mb-1">
              <User className="w-4 h-4" />
              <span>Contacto del donante:</span>
            </div>
            <p className="text-green-700">{request.contact}</p>
          </div>
        )}

        {request.status === "Pendiente" && (
          <div className="text-gray-600">
            <p>Esperando confirmación del donante...</p>
          </div>
        )}

        {request.status === "Entregada" && (
          <Button variant="outline" className="w-full">
            <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
            Ver detalles de entrega
          </Button>
        )}
      </CardContent>
    </Card>
  );

  return (
    <DashboardLayout onNavigate={onNavigate} userType="ngo">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-gray-900 mb-2">Mis solicitudes</h1>
            <p className="text-gray-600">Gestiona el estado de tus solicitudes de alimentos</p>
          </div>
          <Button 
            className="bg-[#4CAF50] hover:bg-[#45a049] text-white"
            onClick={() => onNavigate('ngo-dashboard')}
          >
            Buscar más alimentos
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-[#4CAF50] mb-1">{pendingRequests.length}</div>
                <p className="text-gray-600">Pendientes</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-blue-600 mb-1">{acceptedRequests.length}</div>
                <p className="text-gray-600">Aceptadas</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-green-600 mb-1">{completedRequests.length}</div>
                <p className="text-gray-600">Entregadas</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-red-600 mb-1">{rejectedRequests.length}</div>
                <p className="text-gray-600">Rechazadas</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Requests Tabs */}
        <Card>
          <CardHeader>
            <CardTitle>Estado de solicitudes</CardTitle>
            <CardDescription>Filtra tus solicitudes por estado</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="all">Todas ({requests.length})</TabsTrigger>
                <TabsTrigger value="pending">Pendientes ({pendingRequests.length})</TabsTrigger>
                <TabsTrigger value="accepted">Aceptadas ({acceptedRequests.length})</TabsTrigger>
                <TabsTrigger value="completed">Entregadas ({completedRequests.length})</TabsTrigger>
                <TabsTrigger value="rejected">Rechazadas ({rejectedRequests.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {requests.map(request => (
                    <RequestCard key={request.id} request={request} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="pending" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pendingRequests.length > 0 ? (
                    pendingRequests.map(request => (
                      <RequestCard key={request.id} request={request} />
                    ))
                  ) : (
                    <p className="text-gray-500 col-span-2 text-center py-8">No hay solicitudes pendientes</p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="accepted" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {acceptedRequests.length > 0 ? (
                    acceptedRequests.map(request => (
                      <RequestCard key={request.id} request={request} />
                    ))
                  ) : (
                    <p className="text-gray-500 col-span-2 text-center py-8">No hay solicitudes aceptadas</p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="completed" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {completedRequests.length > 0 ? (
                    completedRequests.map(request => (
                      <RequestCard key={request.id} request={request} />
                    ))
                  ) : (
                    <p className="text-gray-500 col-span-2 text-center py-8">No hay solicitudes completadas</p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="rejected" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {rejectedRequests.length > 0 ? (
                    rejectedRequests.map(request => (
                      <RequestCard key={request.id} request={request} />
                    ))
                  ) : (
                    <p className="text-gray-500 col-span-2 text-center py-8">No hay solicitudes rechazadas</p>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Timeline */}
        <Card>
          <CardHeader>
            <CardTitle>Historial reciente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#4CAF50] mt-2" />
                <div>
                  <p className="text-gray-900">Nueva solicitud enviada a "Supermercado El Ahorro"</p>
                  <p className="text-gray-500">Hoy, 10:30 AM</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-blue-500 mt-2" />
                <div>
                  <p className="text-gray-900">"Panadería La Espiga" aceptó tu solicitud de "Pan del día"</p>
                  <p className="text-gray-500">Ayer, 3:45 PM</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-green-500 mt-2" />
                <div>
                  <p className="text-gray-900">Donación de "Frutas variadas" entregada con éxito</p>
                  <p className="text-gray-500">Hace 3 días</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
