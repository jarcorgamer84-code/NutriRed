import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  MapPin, 
  Calendar, 
  Package,
  Search,
  Filter,
  Heart,
  Clock,
  CheckCircle,
  TrendingUp
} from "lucide-react";
import DashboardLayout from "./DashboardLayout";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export default function NGODashboard({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  
  const [availableDonations] = useState([
    {
      id: 1,
      name: "Verduras frescas variadas",
      donor: "Supermercado El Ahorro",
      quantity: "50 kg",
      category: "Verduras",
      expiry: "2025-10-25",
      location: "Madrid Centro",
      distance: "2.3 km",
      image: "https://images.unsplash.com/photo-1748342319942-223b99937d4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHZlZ2V0YWJsZXMlMjBtYXJrZXR8ZW58MXx8fHwxNzYwOTQ2NzQ3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      urgent: false
    },
    {
      id: 2,
      name: "Pan del día",
      donor: "Panadería La Espiga",
      quantity: "30 unidades",
      category: "Panadería",
      expiry: "2025-10-21",
      location: "Madrid Norte",
      distance: "4.1 km",
      image: "",
      urgent: true
    },
    {
      id: 3,
      name: "Frutas variadas",
      donor: "Frutería Los Naranjos",
      quantity: "40 kg",
      category: "Frutas",
      expiry: "2025-10-27",
      location: "Madrid Sur",
      distance: "5.8 km",
      image: "https://images.unsplash.com/photo-1623428454609-8ed6a4628b66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmdhbmljJTIwZm9vZCUyMGJhc2tldHxlbnwxfHx8fDE3NjA5NzA2MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      urgent: false
    },
    {
      id: 4,
      name: "Productos lácteos",
      donor: "Supermercado Fresh",
      quantity: "25 litros",
      category: "Lácteos",
      expiry: "2025-10-30",
      location: "Madrid Este",
      distance: "3.2 km",
      image: "",
      urgent: false
    },
    {
      id: 5,
      name: "Conservas variadas",
      donor: "Almacén Central",
      quantity: "100 unidades",
      category: "Conservas",
      expiry: "2026-06-15",
      location: "Madrid Centro",
      distance: "1.9 km",
      image: "",
      urgent: false
    },
    {
      id: 6,
      name: "Arroz y legumbres",
      donor: "Distribuidora Granos",
      quantity: "80 kg",
      category: "Granos",
      expiry: "2026-03-20",
      location: "Madrid Oeste",
      distance: "6.5 km",
      image: "",
      urgent: false
    }
  ]);

  const filteredDonations = availableDonations.filter(donation => {
    const matchesSearch = donation.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         donation.donor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "all" || donation.category.toLowerCase() === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <DashboardLayout onNavigate={onNavigate} userType="ngo">
      <div className="space-y-6">
        {/* Welcome Card */}
        <Card className="bg-gradient-to-r from-[#4CAF50] to-[#45a049] text-white">
          <CardContent className="pt-6">
            <h2 className="mb-2">¡Bienvenido, Fundación Alimentos para Todos!</h2>
            <p className="opacity-90">
              Encuentra alimentos disponibles cerca de ti y ayuda a tu comunidad.
            </p>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Solicitudes activas</p>
                  <div className="text-[#4CAF50]">8</div>
                </div>
                <Clock className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Alimentos recibidos</p>
                  <div className="text-[#4CAF50]">892 kg</div>
                </div>
                <Package className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Familias ayudadas</p>
                  <div className="text-[#4CAF50]">156</div>
                </div>
                <Heart className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Tasa de éxito</p>
                  <div className="text-[#4CAF50]">94%</div>
                </div>
                <TrendingUp className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map Simulation */}
        <Card>
          <CardHeader>
            <CardTitle>Mapa de donantes cercanos</CardTitle>
            <CardDescription>Visualiza las ubicaciones de alimentos disponibles</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative h-80 bg-gray-100 rounded-lg overflow-hidden">
              {/* Simulated Map Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-blue-100">
                {/* Grid pattern to simulate map */}
                <div className="absolute inset-0 opacity-10" 
                     style={{
                       backgroundImage: 'linear-gradient(#000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)',
                       backgroundSize: '50px 50px'
                     }}
                />
                
                {/* Simulated location markers */}
                <div className="absolute top-[30%] left-[40%] w-8 h-8 bg-[#4CAF50] rounded-full border-4 border-white shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                <div className="absolute top-[50%] left-[60%] w-8 h-8 bg-[#4CAF50] rounded-full border-4 border-white shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                <div className="absolute top-[70%] left-[35%] w-8 h-8 bg-[#4CAF50] rounded-full border-4 border-white shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                <div className="absolute top-[40%] left-[75%] w-8 h-8 bg-[#4CAF50] rounded-full border-4 border-white shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                <div className="absolute top-[60%] left-[20%] w-8 h-8 bg-[#4CAF50] rounded-full border-4 border-white shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                
                {/* Center marker (user location) */}
                <div className="absolute top-[50%] left-[50%] -translate-x-1/2 -translate-y-1/2">
                  <div className="w-12 h-12 bg-blue-500 rounded-full border-4 border-white shadow-lg flex items-center justify-center animate-pulse">
                    <div className="w-3 h-3 bg-white rounded-full" />
                  </div>
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap bg-white px-2 py-1 rounded shadow text-blue-500">
                    Tu ubicación
                  </div>
                </div>
              </div>

              {/* Map controls */}
              <div className="absolute top-4 right-4 flex flex-col gap-2">
                <Button size="icon" className="bg-white text-gray-700 hover:bg-gray-100">+</Button>
                <Button size="icon" className="bg-white text-gray-700 hover:bg-gray-100">-</Button>
              </div>

              {/* Legend */}
              <div className="absolute bottom-4 left-4 bg-white p-3 rounded shadow">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-3 h-3 bg-[#4CAF50] rounded-full" />
                  <span className="text-gray-700">Donaciones disponibles</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full" />
                  <span className="text-gray-700">Tu ubicación</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Search and Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar alimentos o donantes..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Categoría" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las categorías</SelectItem>
                  <SelectItem value="verduras">Verduras</SelectItem>
                  <SelectItem value="frutas">Frutas</SelectItem>
                  <SelectItem value="lácteos">Lácteos</SelectItem>
                  <SelectItem value="panadería">Panadería</SelectItem>
                  <SelectItem value="conservas">Conservas</SelectItem>
                  <SelectItem value="granos">Granos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Available Donations */}
        <Card>
          <CardHeader>
            <CardTitle>Alimentos disponibles ({filteredDonations.length})</CardTitle>
            <CardDescription>Solicita los alimentos que necesites para tu comunidad</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDonations.map((donation) => (
                <Card key={donation.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  {donation.image && (
                    <div className="h-40 overflow-hidden">
                      <ImageWithFallback
                        src={donation.image}
                        alt={donation.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-gray-900">{donation.name}</h4>
                      {donation.urgent && (
                        <Badge className="bg-red-100 text-red-800 ml-2">Urgente</Badge>
                      )}
                    </div>
                    <p className="text-gray-600 mb-3">{donation.donor}</p>
                    <div className="space-y-2 text-gray-600 mb-4">
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4" />
                        <span>{donation.quantity}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>Vence: {donation.expiry}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        <span>{donation.location} ({donation.distance})</span>
                      </div>
                    </div>
                    <Button 
                      className="w-full bg-[#4CAF50] hover:bg-[#45a049] text-white"
                      onClick={() => onNavigate('ngo-requests')}
                    >
                      <Heart className="w-4 h-4 mr-2" />
                      Solicitar alimento
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
