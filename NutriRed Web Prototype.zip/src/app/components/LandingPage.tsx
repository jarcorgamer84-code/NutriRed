import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Users, PackageCheck, TrendingUp, Heart, Leaf, HandHeart } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export default function LandingPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b sticky top-0 bg-white z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8 text-[#4CAF50]" />
            <span className="text-[#4CAF50]">NutriRed</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <a href="#nosotros" className="text-gray-600 hover:text-[#4CAF50] transition-colors">Nosotros</a>
            <a href="#como-funciona" className="text-gray-600 hover:text-[#4CAF50] transition-colors">Cómo funciona</a>
            <a href="#impacto" className="text-gray-600 hover:text-[#4CAF50] transition-colors">Impacto</a>
            <a href="#testimonios" className="text-gray-600 hover:text-[#4CAF50] transition-colors">Testimonios</a>
          </nav>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onNavigate('login')}>
              Iniciar sesión
            </Button>
            <Button 
              className="bg-[#4CAF50] hover:bg-[#45a049] text-white"
              onClick={() => onNavigate('register')}
            >
              Registrarse
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-gray-900 mb-6">
                Conectando alimentos con quienes más lo necesitan
              </h1>
              <p className="text-gray-600 mb-8">
                NutriRed es la plataforma que une a donantes de alimentos con organizaciones sociales 
                y comunidades vulnerables, promoviendo la sostenibilidad y reduciendo el desperdicio alimentario.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button 
                  className="bg-[#4CAF50] hover:bg-[#45a049] text-white"
                  onClick={() => onNavigate('register')}
                >
                  <HandHeart className="w-4 h-4 mr-2" />
                  Donar alimentos
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => onNavigate('register')}
                >
                  <Heart className="w-4 h-4 mr-2" />
                  Solicitar alimentos
                </Button>
              </div>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1593113630400-ea4288922497?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwZG9uYXRpb24lMjB2b2x1bnRlZXJzfGVufDF8fHx8MTc2MDkxMjU0MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Donación de alimentos"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Impact Numbers */}
      <section id="impacto" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Nuestro impacto en números</h2>
            <p className="text-gray-600">Juntos estamos construyendo un mundo más sostenible</p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            <Card className="text-center">
              <CardContent className="pt-6">
                <PackageCheck className="w-12 h-12 text-[#4CAF50] mx-auto mb-4" />
                <div className="text-[#4CAF50] mb-2">12,450 kg</div>
                <p className="text-gray-600">Alimentos rescatados</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <Users className="w-12 h-12 text-[#4CAF50] mx-auto mb-4" />
                <div className="text-[#4CAF50] mb-2">3,200+</div>
                <p className="text-gray-600">Beneficiarios activos</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <HandHeart className="w-12 h-12 text-[#4CAF50] mx-auto mb-4" />
                <div className="text-[#4CAF50] mb-2">245</div>
                <p className="text-gray-600">Donantes activos</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <TrendingUp className="w-12 h-12 text-[#4CAF50] mx-auto mb-4" />
                <div className="text-[#4CAF50] mb-2">89%</div>
                <p className="text-gray-600">Tasa de éxito</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="como-funciona" className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">¿Cómo funciona?</h2>
            <p className="text-gray-600">Tres simples pasos para hacer la diferencia</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="w-12 h-12 rounded-full bg-[#4CAF50] text-white flex items-center justify-center mb-4">
                  1
                </div>
                <h3 className="text-gray-900 mb-2">Regístrate</h3>
                <p className="text-gray-600">
                  Crea tu cuenta como donante u organización beneficiaria en minutos.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="w-12 h-12 rounded-full bg-[#4CAF50] text-white flex items-center justify-center mb-4">
                  2
                </div>
                <h3 className="text-gray-900 mb-2">Publica o solicita</h3>
                <p className="text-gray-600">
                  Donantes publican alimentos disponibles, beneficiarios solicitan lo que necesitan.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="w-12 h-12 rounded-full bg-[#4CAF50] text-white flex items-center justify-center mb-4">
                  3
                </div>
                <h3 className="text-gray-900 mb-2">Coordina y entrega</h3>
                <p className="text-gray-600">
                  Conectamos donantes con beneficiarios para coordinar la entrega de alimentos.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonios" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Lo que dicen nuestros usuarios</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <p className="text-gray-600 mb-4">
                  "Gracias a NutriRed hemos podido ayudar a más de 500 familias en nuestra comunidad. 
                  La plataforma es fácil de usar y muy efectiva."
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#4CAF50] text-white flex items-center justify-center">
                    MC
                  </div>
                  <div>
                    <div className="text-gray-900">María Contreras</div>
                    <div className="text-gray-500">ONG Alimentos para Todos</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <p className="text-gray-600 mb-4">
                  "Como supermercado, podemos reducir el desperdicio y al mismo tiempo ayudar a quienes 
                  lo necesitan. Es una solución win-win."
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#4CAF50] text-white flex items-center justify-center">
                    JR
                  </div>
                  <div>
                    <div className="text-gray-900">Jorge Ramírez</div>
                    <div className="text-gray-500">Supermercado El Progreso</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <p className="text-gray-600 mb-4">
                  "La coordinación es muy simple y el impacto es inmediato. Recomiendo NutriRed 
                  a todas las organizaciones sociales."
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#4CAF50] text-white flex items-center justify-center">
                    AL
                  </div>
                  <div>
                    <div className="text-gray-900">Ana López</div>
                    <div className="text-gray-500">Fundación Nutrición Comunitaria</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Leaf className="w-6 h-6 text-[#4CAF50]" />
                <span>NutriRed</span>
              </div>
              <p className="text-gray-400">
                Conectando alimentos con quienes más lo necesitan.
              </p>
            </div>
            <div>
              <h4 className="mb-4">Plataforma</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Para donantes</a></li>
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Para ONGs</a></li>
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Cómo funciona</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Empresa</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Sobre nosotros</a></li>
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Contacto</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Términos de uso</a></li>
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Privacidad</a></li>
                <li><a href="#" className="hover:text-[#4CAF50] transition-colors">Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 NutriRed. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
