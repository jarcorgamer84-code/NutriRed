import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Package, 
  TrendingUp, 
  Clock, 
  CheckCircle, 
  Plus,
  Users,
  MapPin,
  Calendar,
  Edit,
  Trash2
} from "lucide-react";
import DashboardLayout from "./DashboardLayout";

export default function DonorDashboard({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [donations] = useState([
    {
      id: 1,
      name: "Verduras frescas variadas",
      quantity: "50 kg",
      category: "Verduras",
      expiry: "2025-10-25",
      status: "Publicado",
      location: "Madrid, España",
      requests: 3
    },
    {
      id: 2,
      name: "Pan del día",
      quantity: "30 unidades",
      category: "Panadería",
      expiry: "2025-10-21",
      status: "En proceso",
      location: "Madrid, España",
      requests: 1
    },
    {
      id: 3,
      name: "Frutas variadas",
      quantity: "40 kg",
      category: "Frutas",
      expiry: "2025-10-27",
      status: "Entregado",
      location: "Madrid, España",
      requests: 0
    },
    {
      id: 4,
      name: "Productos lácteos",
      quantity: "25 litros",
      category: "Lácteos",
      expiry: "2025-10-30",
      status: "Publicado",
      location: "Madrid, España",
      requests: 2
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Publicado": return "bg-blue-100 text-blue-800";
      case "En proceso": return "bg-yellow-100 text-yellow-800";
      case "Entregado": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <DashboardLayout onNavigate={onNavigate} userType="donante">
      <div className="space-y-6">
        {/* Welcome Card */}
        <Card className="bg-gradient-to-r from-[#4CAF50] to-[#45a049] text-white">
          <CardContent className="pt-6">
            <h2 className="mb-2">¡Bienvenido, Supermercado El Ahorro!</h2>
            <p className="opacity-90">
              Gracias por contribuir a un mundo más sostenible. Tu impacto está ayudando a cientos de familias.
            </p>
            <Button 
              className="mt-4 bg-white text-[#4CAF50] hover:bg-gray-100"
              onClick={() => onNavigate('publish-donation')}
            >
              <Plus className="w-4 h-4 mr-2" />
              Publicar nueva donación
            </Button>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Total donaciones</p>
                  <div className="text-[#4CAF50]">47</div>
                </div>
                <Package className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Alimentos entregados</p>
                  <div className="text-[#4CAF50]">1,245 kg</div>
                </div>
                <CheckCircle className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Familias ayudadas</p>
                  <div className="text-[#4CAF50]">312</div>
                </div>
                <Users className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600">Solicitudes activas</p>
                  <div className="text-[#4CAF50]">6</div>
                </div>
                <Clock className="w-10 h-10 text-[#4CAF50] opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Impact Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Impacto mensual</CardTitle>
            <CardDescription>Evolución de tus donaciones en los últimos 6 meses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-end justify-between gap-4">
              {[180, 220, 190, 250, 210, 280].map((height, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                  <div className="text-[#4CAF50]">{height}kg</div>
                  <div 
                    className="w-full bg-[#4CAF50] rounded-t-lg transition-all hover:bg-[#45a049]"
                    style={{ height: `${(height / 280) * 200}px` }}
                  />
                  <div className="text-gray-500">
                    {['May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct'][idx]}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Donations Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Mis donaciones</CardTitle>
                <CardDescription>Gestiona tus alimentos publicados</CardDescription>
              </div>
              <Button 
                className="bg-[#4CAF50] hover:bg-[#45a049] text-white"
                onClick={() => onNavigate('publish-donation')}
              >
                <Plus className="w-4 h-4 mr-2" />
                Nueva donación
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {donations.map((donation) => (
                <div 
                  key={donation.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-gray-900">{donation.name}</h4>
                      <Badge className={getStatusColor(donation.status)}>
                        {donation.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-gray-600">
                      <div className="flex items-center gap-1">
                        <Package className="w-4 h-4" />
                        <span>{donation.quantity}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>Vence: {donation.expiry}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{donation.location}</span>
                      </div>
                      {donation.requests > 0 && (
                        <div className="flex items-center gap-1 text-[#4CAF50]">
                          <TrendingUp className="w-4 h-4" />
                          <span>{donation.requests} solicitudes</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    <Button variant="outline" size="icon">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="icon">
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Actividad reciente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#4CAF50] mt-2" />
                <div>
                  <p className="text-gray-900">Fundación Alimentos para Todos solicitó "Verduras frescas variadas"</p>
                  <p className="text-gray-500">Hace 2 horas</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-green-500 mt-2" />
                <div>
                  <p className="text-gray-900">Donación "Frutas variadas" fue entregada exitosamente</p>
                  <p className="text-gray-500">Hace 5 horas</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#4CAF50] mt-2" />
                <div>
                  <p className="text-gray-900">Comedor Social San José solicitó "Productos lácteos"</p>
                  <p className="text-gray-500">Ayer</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
