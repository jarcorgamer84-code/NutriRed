import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Alert, AlertDescription } from "./ui/alert";
import { ArrowLeft, Upload, CheckCircle } from "lucide-react";
import DashboardLayout from "./DashboardLayout";

export default function PublishDonationForm({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [success, setSuccess] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccess(true);
    setTimeout(() => {
      onNavigate('donor-dashboard');
    }, 2000);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <DashboardLayout onNavigate={onNavigate} userType="donante">
      <div className="max-w-3xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-4"
          onClick={() => onNavigate('donor-dashboard')}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver al dashboard
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Publicar nueva donación</CardTitle>
            <CardDescription>
              Completa los detalles de los alimentos que deseas donar
            </CardDescription>
          </CardHeader>
          <CardContent>
            {success && (
              <Alert className="mb-6 border-[#4CAF50] bg-green-50">
                <CheckCircle className="w-4 h-4 text-[#4CAF50]" />
                <AlertDescription className="text-[#4CAF50]">
                  ¡Donación publicada exitosamente! Las organizaciones cercanas serán notificadas.
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Nombre del alimento */}
              <div className="space-y-2">
                <Label htmlFor="food-name">Nombre del alimento *</Label>
                <Input
                  id="food-name"
                  placeholder="Ej: Verduras frescas variadas"
                  required
                />
              </div>

              {/* Categoría */}
              <div className="space-y-2">
                <Label htmlFor="category">Categoría *</Label>
                <Select required>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona una categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="verduras">Verduras</SelectItem>
                    <SelectItem value="frutas">Frutas</SelectItem>
                    <SelectItem value="lacteos">Lácteos</SelectItem>
                    <SelectItem value="panaderia">Panadería</SelectItem>
                    <SelectItem value="carnes">Carnes y pescados</SelectItem>
                    <SelectItem value="conservas">Conservas</SelectItem>
                    <SelectItem value="granos">Granos y cereales</SelectItem>
                    <SelectItem value="bebidas">Bebidas</SelectItem>
                    <SelectItem value="otros">Otros</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Cantidad */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Cantidad *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="50"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit">Unidad *</Label>
                  <Select required>
                    <SelectTrigger>
                      <SelectValue placeholder="Unidad" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">Kilogramos (kg)</SelectItem>
                      <SelectItem value="unidades">Unidades</SelectItem>
                      <SelectItem value="litros">Litros</SelectItem>
                      <SelectItem value="paquetes">Paquetes</SelectItem>
                      <SelectItem value="cajas">Cajas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Fecha de vencimiento */}
              <div className="space-y-2">
                <Label htmlFor="expiry">Fecha de vencimiento *</Label>
                <Input
                  id="expiry"
                  type="date"
                  required
                />
                <p className="text-gray-500">Indica hasta cuándo el alimento está en buen estado</p>
              </div>

              {/* Descripción */}
              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  placeholder="Describe el estado, variedad o información adicional sobre los alimentos..."
                  rows={4}
                />
              </div>

              {/* Ubicación */}
              <div className="space-y-2">
                <Label htmlFor="location">Ubicación de recogida *</Label>
                <Input
                  id="location"
                  placeholder="Dirección completa"
                  required
                />
              </div>

              {/* Horario de recogida */}
              <div className="space-y-2">
                <Label htmlFor="pickup-hours">Horario de recogida</Label>
                <Input
                  id="pickup-hours"
                  placeholder="Ej: Lunes a viernes de 9:00 a 18:00"
                />
              </div>

              {/* Condiciones especiales */}
              <div className="space-y-2">
                <Label htmlFor="conditions">Condiciones de transporte</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona las condiciones necesarias" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ambient">Temperatura ambiente</SelectItem>
                    <SelectItem value="refrigerated">Requiere refrigeración</SelectItem>
                    <SelectItem value="frozen">Congelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Foto del alimento */}
              <div className="space-y-2">
                <Label htmlFor="photo">Foto del alimento (opcional)</Label>
                <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-[#4CAF50] transition-colors cursor-pointer">
                  <input
                    id="photo"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageChange}
                  />
                  <label htmlFor="photo" className="cursor-pointer">
                    {imagePreview ? (
                      <img src={imagePreview} alt="Preview" className="max-h-48 mx-auto rounded" />
                    ) : (
                      <>
                        <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-600">Haz clic para subir una imagen</p>
                        <p className="text-gray-400">PNG, JPG hasta 5MB</p>
                      </>
                    )}
                  </label>
                </div>
              </div>

              {/* Botones */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => onNavigate('donor-dashboard')}
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-[#4CAF50] hover:bg-[#45a049] text-white"
                >
                  Publicar donación
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
