import { ReactNode, useState } from "react";
import { Button } from "./ui/button";
import { 
  Leaf, 
  LayoutDashboard, 
  Package, 
  Heart, 
  Settings, 
  LogOut,
  Menu,
  X,
  BarChart3,
  Users,
  FileText,
  Bell
} from "lucide-react";
import { Badge } from "./ui/badge";

interface DashboardLayoutProps {
  children: ReactNode;
  onNavigate: (page: string) => void;
  userType: 'donante' | 'ngo' | 'admin';
}

export default function DashboardLayout({ children, onNavigate, userType }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const donorMenuItems = [
    { icon: LayoutDashboard, label: "Dashboard", page: "donor-dashboard" },
    { icon: Package, label: "Mis donaciones", page: "donor-dashboard" },
    { icon: FileText, label: "Solicitudes", page: "requests" },
    { icon: Settings, label: "Configuración", page: "settings" }
  ];

  const ngoMenuItems = [
    { icon: LayoutDashboard, label: "Dashboard", page: "ngo-dashboard" },
    { icon: Heart, label: "Alimentos disponibles", page: "ngo-dashboard" },
    { icon: FileText, label: "Mis solicitudes", page: "ngo-requests" },
    { icon: Settings, label: "Configuración", page: "settings" }
  ];

  const adminMenuItems = [
    { icon: LayoutDashboard, label: "Dashboard", page: "admin-dashboard" },
    { icon: BarChart3, label: "Métricas", page: "admin-dashboard" },
    { icon: Users, label: "Usuarios", page: "admin-users" },
    { icon: Package, label: "Donaciones", page: "admin-donations" },
    { icon: Settings, label: "Configuración", page: "settings" }
  ];

  const menuItems = userType === 'admin' ? adminMenuItems : 
                    userType === 'ngo' ? ngoMenuItems : 
                    donorMenuItems;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
            <div className="flex items-center gap-2">
              <Leaf className="w-8 h-8 text-[#4CAF50]" />
              <span className="text-[#4CAF50]">NutriRed</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 bg-red-500">
                3
              </Badge>
            </Button>
            <div className="hidden md:flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#4CAF50] text-white flex items-center justify-center">
                {userType === 'admin' ? 'AD' : userType === 'ngo' ? 'ON' : 'DO'}
              </div>
              <div className="text-right">
                <div className="text-gray-900">
                  {userType === 'admin' ? 'Administrador' : 
                   userType === 'ngo' ? 'ONG Alimentos' : 
                   'Supermercado El Ahorro'}
                </div>
                <div className="text-gray-500">
                  {userType === 'admin' ? 'Admin' : 
                   userType === 'ngo' ? 'Beneficiario' : 
                   'Donante'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside 
          className={`
            fixed md:static inset-y-0 left-0 z-30
            w-64 bg-white border-r transform transition-transform duration-200 ease-in-out
            ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
            mt-[57px] md:mt-0
          `}
        >
          <nav className="p-4 space-y-2">
            {menuItems.map((item, idx) => (
              <Button
                key={idx}
                variant="ghost"
                className="w-full justify-start hover:bg-green-50 hover:text-[#4CAF50]"
                onClick={() => {
                  onNavigate(item.page);
                  setSidebarOpen(false);
                }}
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.label}
              </Button>
            ))}
            <div className="pt-4 border-t">
              <Button
                variant="ghost"
                className="w-full justify-start text-red-500 hover:bg-red-50 hover:text-red-600"
                onClick={() => onNavigate('landing')}
              >
                <LogOut className="w-5 h-5 mr-3" />
                Cerrar sesión
              </Button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
