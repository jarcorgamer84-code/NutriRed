import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { 
  Users, 
  Package, 
  TrendingUp, 
  Activity,
  Download,
  ArrowUpRight,
  ArrowDownRight
} from "lucide-react";
import DashboardLayout from "./DashboardLayout";

export default function AdminDashboard({ onNavigate }: { onNavigate: (page: string) => void }) {
  const monthlyData = [
    { month: 'Abr', donations: 45, users: 28, kg: 850 },
    { month: 'May', donations: 52, users: 35, kg: 980 },
    { month: 'Jun', donations: 48, users: 42, kg: 920 },
    { month: 'Jul', donations: 65, users: 58, kg: 1240 },
    { month: 'Ago', donations: 71, users: 67, kg: 1380 },
    { month: 'Sep', donations: 78, users: 75, kg: 1520 },
    { month: 'Oct', donations: 89, users: 89, kg: 1750 }
  ];

  const recentActivity = [
    { user: "Supermercado El Ahorro", action: "publicó una nueva donación", time: "Hace 15 min", type: "donation" },
    { user: "ONG Alimentos Unidos", action: "se registró en la plataforma", time: "Hace 1 hora", type: "registration" },
    { user: "Panadería La Espiga", action: "entregó 30kg de pan", time: "Hace 2 horas", type: "delivery" },
    { user: "Fundación Comida Solidaria", action: "solicitó verduras frescas", time: "Hace 3 horas", type: "request" },
    { user: "Frutería Los Naranjos", action: "publicó frutas variadas", time: "Hace 4 horas", type: "donation" }
  ];

  const topDonors = [
    { name: "Supermercado El Ahorro", donations: 47, kg: 1245 },
    { name: "Panadería La Espiga", donations: 38, kg: 890 },
    { name: "Frutería Los Naranjos", donations: 31, kg: 1050 },
    { name: "Distribuidora Granos", donations: 28, kg: 980 },
    { name: "Almacén Central", donations: 24, kg: 760 }
  ];

  const topBeneficiaries = [
    { name: "Fundación Alimentos para Todos", requests: 52, kg: 892 },
    { name: "ONG Comida Solidaria", requests: 41, kg: 715 },
    { name: "Comedor Social San José", requests: 35, kg: 620 },
    { name: "Asociación Ayuda Comunitaria", requests: 28, kg: 510 },
    { name: "Fundación Nutrición Infantil", requests: 22, kg: 445 }
  ];

  return (
    <DashboardLayout onNavigate={onNavigate} userType="admin">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-gray-900 mb-2">Panel de Administración</h1>
            <p className="text-gray-600">Vista general de la plataforma NutriRed</p>
          </div>
          <Button className="bg-[#4CAF50] hover:bg-[#45a049] text-white">
            <Download className="w-4 h-4 mr-2" />
            Exportar reporte
          </Button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-gray-600">Usuarios totales</p>
                <Users className="w-5 h-5 text-[#4CAF50]" />
              </div>
              <div className="text-[#4CAF50] mb-1">3,487</div>
              <div className="flex items-center gap-1 text-green-600">
                <ArrowUpRight className="w-4 h-4" />
                <span>+12% vs mes anterior</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-gray-600">Donaciones activas</p>
                <Package className="w-5 h-5 text-[#4CAF50]" />
              </div>
              <div className="text-[#4CAF50] mb-1">245</div>
              <div className="flex items-center gap-1 text-green-600">
                <ArrowUpRight className="w-4 h-4" />
                <span>+8% vs mes anterior</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-gray-600">Alimentos distribuidos</p>
                <TrendingUp className="w-5 h-5 text-[#4CAF50]" />
              </div>
              <div className="text-[#4CAF50] mb-1">12,450 kg</div>
              <div className="flex items-center gap-1 text-green-600">
                <ArrowUpRight className="w-4 h-4" />
                <span>+15% vs mes anterior</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-gray-600">Tasa de éxito</p>
                <Activity className="w-5 h-5 text-[#4CAF50]" />
              </div>
              <div className="text-[#4CAF50] mb-1">89.4%</div>
              <div className="flex items-center gap-1 text-red-600">
                <ArrowDownRight className="w-4 h-4" />
                <span>-2% vs mes anterior</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Donations Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Donaciones mensuales</CardTitle>
              <CardDescription>Evolución de donaciones en los últimos 7 meses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-2">
                {monthlyData.map((data, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                    <div className="text-[#4CAF50]">{data.donations}</div>
                    <div 
                      className="w-full bg-[#4CAF50] rounded-t-lg transition-all hover:bg-[#45a049] cursor-pointer relative group"
                      style={{ height: `${(data.donations / 90) * 200}px` }}
                    >
                      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                        {data.kg}kg
                      </div>
                    </div>
                    <div className="text-gray-500">{data.month}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Users Growth Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Crecimiento de usuarios</CardTitle>
              <CardDescription>Nuevos usuarios registrados por mes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between gap-2">
                {monthlyData.map((data, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                    <div className="text-blue-600">{data.users}</div>
                    <div 
                      className="w-full bg-blue-500 rounded-t-lg transition-all hover:bg-blue-600 cursor-pointer"
                      style={{ height: `${(data.users / 90) * 200}px` }}
                    />
                    <div className="text-gray-500">{data.month}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Distribution by Category */}
        <Card>
          <CardHeader>
            <CardTitle>Distribución por categoría de alimentos</CardTitle>
            <CardDescription>Porcentaje de donaciones por tipo de alimento</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { category: "Verduras", percentage: 28, color: "bg-green-500" },
                { category: "Frutas", percentage: 22, color: "bg-orange-500" },
                { category: "Panadería", percentage: 18, color: "bg-yellow-600" },
                { category: "Lácteos", percentage: 15, color: "bg-blue-500" },
                { category: "Conservas", percentage: 10, color: "bg-purple-500" },
                { category: "Otros", percentage: 7, color: "bg-gray-500" }
              ].map((item, idx) => (
                <div key={idx}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-700">{item.category}</span>
                    <span className="text-gray-900">{item.percentage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`${item.color} h-2 rounded-full transition-all`}
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Performers */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Donors */}
          <Card>
            <CardHeader>
              <CardTitle>Top Donantes</CardTitle>
              <CardDescription>Organizaciones con más donaciones</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topDonors.map((donor, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#4CAF50] text-white flex items-center justify-center">
                        {idx + 1}
                      </div>
                      <div>
                        <div className="text-gray-900">{donor.name}</div>
                        <div className="text-gray-500">{donor.donations} donaciones</div>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">
                      {donor.kg} kg
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Beneficiaries */}
          <Card>
            <CardHeader>
              <CardTitle>Top Beneficiarios</CardTitle>
              <CardDescription>ONGs más activas en la plataforma</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topBeneficiaries.map((beneficiary, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-500 text-white flex items-center justify-center">
                        {idx + 1}
                      </div>
                      <div>
                        <div className="text-gray-900">{beneficiary.name}</div>
                        <div className="text-gray-500">{beneficiary.requests} solicitudes</div>
                      </div>
                    </div>
                    <Badge className="bg-blue-100 text-blue-800">
                      {beneficiary.kg} kg
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Actividad reciente</CardTitle>
            <CardDescription>Últimas acciones en la plataforma</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, idx) => (
                <div key={idx} className="flex items-start gap-3 pb-4 border-b last:border-0">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    activity.type === 'donation' ? 'bg-[#4CAF50]' :
                    activity.type === 'registration' ? 'bg-blue-500' :
                    activity.type === 'delivery' ? 'bg-green-500' :
                    'bg-orange-500'
                  }`} />
                  <div className="flex-1">
                    <p className="text-gray-900">
                      <span>{activity.user}</span> {activity.action}
                    </p>
                    <p className="text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
