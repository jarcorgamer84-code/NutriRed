import { useState } from 'react';
import LandingPage from './components/LandingPage';
import AuthPage from './components/AuthPage';
import DonorDashboard from './components/DonorDashboard';
import NGODashboard from './components/NGODashboard';
import NGORequests from './components/NGORequests';
import AdminDashboard from './components/AdminDashboard';
import PublishDonationForm from './components/PublishDonationForm';
import { Toaster } from './components/ui/sonner';

type Page = 
  | 'landing' 
  | 'login' 
  | 'register' 
  | 'donor-dashboard' 
  | 'ngo-dashboard'
  | 'ngo-requests'
  | 'admin-dashboard'
  | 'publish-donation';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  return (
    <>
      {currentPage === 'landing' && <LandingPage onNavigate={handleNavigate} />}
      {(currentPage === 'login' || currentPage === 'register') && (
        <AuthPage onNavigate={handleNavigate} />
      )}
      {currentPage === 'donor-dashboard' && <DonorDashboard onNavigate={handleNavigate} />}
      {currentPage === 'ngo-dashboard' && <NGODashboard onNavigate={handleNavigate} />}
      {currentPage === 'ngo-requests' && <NGORequests onNavigate={handleNavigate} />}
      {currentPage === 'admin-dashboard' && <AdminDashboard onNavigate={handleNavigate} />}
      {currentPage === 'publish-donation' && <PublishDonationForm onNavigate={handleNavigate} />}
      <Toaster />
    </>
  );
}
