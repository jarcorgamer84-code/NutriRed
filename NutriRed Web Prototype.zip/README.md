
  # NutriRed Web Prototype

  This is a code bundle for NutriRed Web Prototype. The original project is available at https://www.figma.com/design/18P3VvsacgdL2g4E0yV85N/NutriRed-Web-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  